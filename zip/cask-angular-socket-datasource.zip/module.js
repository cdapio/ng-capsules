angular.module('cask-angular-socket-datasource', [
  'cask-angular-eventpipe',
  'cask-angular-window-manager',
  'cask-angular-observable-promise'
]);
