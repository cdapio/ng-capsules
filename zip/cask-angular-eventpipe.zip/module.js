angular.module('cask-angular-eventpipe', []);
