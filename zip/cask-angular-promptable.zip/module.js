angular.module('cask-angular-promptable', [
  'mgcrea.ngStrap.modal',
  'cask-angular-focus'
]);
