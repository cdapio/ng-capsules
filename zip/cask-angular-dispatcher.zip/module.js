angular.module('cask-angular-dispatcher', []);
