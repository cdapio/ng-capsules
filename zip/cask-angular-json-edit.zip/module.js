angular.module('cask-angular-json-edit', [])
