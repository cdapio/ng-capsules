angular.module('cask-angular-progress', []);
