angular.module('cask-angular-window-manager', []);
