angular.module('cask-angular-focus', []);
