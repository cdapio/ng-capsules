angular.module('cask-angular-confirmable', [
  'mgcrea.ngStrap.modal'
]);
