angular.module('cask-angular-confirmable', []);
