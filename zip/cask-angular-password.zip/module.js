angular.module('cask-angular-password', [
  'cask-angular-focus'
]);
