angular.module('cask-angular-theme', [
  'ngStorage'
]);
