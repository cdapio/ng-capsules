angular.module('cask-angular-dropdown-text-combo', [
  'cask-angular-capitalize'
]);
