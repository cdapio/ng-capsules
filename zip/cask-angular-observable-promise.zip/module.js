angular.module('cask-angular-observable-promise', []);
