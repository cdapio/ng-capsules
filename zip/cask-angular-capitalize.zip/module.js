angular.module('cask-angular-capitalize', []);
